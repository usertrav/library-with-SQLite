class Zhanr < ApplicationRecord
end
