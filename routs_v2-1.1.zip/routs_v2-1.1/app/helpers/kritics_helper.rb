module KriticsHelper
end
