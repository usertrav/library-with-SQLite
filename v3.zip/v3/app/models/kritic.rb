class Kritic < ApplicationRecord
end
