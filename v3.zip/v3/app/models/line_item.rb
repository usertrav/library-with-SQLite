class LineItem < ApplicationRecord
	belongs_to :book
end
